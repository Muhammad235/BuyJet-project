<x-mail::message>
# Email OTP Verificatin

Below is your one time passwcode that you need
to complete your authentication.
The verification code will be valid for 10 minutes.
Please do not share this code with anyone.

 <p style="text-align: center; background-color: rgba(100, 98, 98, 0.425); color: #ffffff; padding: 5px;"> <b>{{ $otp  }}</b></p>

 {{-- Enjoy the fastest & most secure way of buying & selling crypto and giftcards at cheap rates.
<br> --}}

<b>{{ config('app.name') }}</b>
</x-mail::message>
